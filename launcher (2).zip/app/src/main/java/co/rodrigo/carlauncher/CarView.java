package co.rodrigo.carlauncher;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.view.View;

/** Dibujo sencillo del Mazda 2 de frente; los faros se iluminan cuando on = true. */
public class CarView extends View {
    private boolean on = false;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

    public CarView(Context c) {
        super(c);
    }

    public void setLights(boolean b) {
        on = b;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas c) {
        float w = getWidth(), h = getHeight();
        float cx = w / 2f;
        float bw = Math.min(w * 0.85f, h * 1.5f);
        float bh = bw * 0.5f;
        float top = h / 2f - bh / 2f;

        if (on) {
            float r = bw * 0.3f;
            float gy = top + bh * 0.58f;
            p.setShader(new RadialGradient(cx - bw * 0.33f, gy, r, 0xAAFFE9A0, 0x00FFE9A0, Shader.TileMode.CLAMP));
            c.drawCircle(cx - bw * 0.33f, gy, r, p);
            p.setShader(new RadialGradient(cx + bw * 0.33f, gy, r, 0xAAFFE9A0, 0x00FFE9A0, Shader.TileMode.CLAMP));
            c.drawCircle(cx + bw * 0.33f, gy, r, p);
            p.setShader(null);
        }
        // carrocería
        p.setColor(0xFFE8ECF2);
        c.drawRoundRect(new RectF(cx - bw / 2f, top + bh * 0.28f, cx + bw / 2f, top + bh * 0.92f), bw * 0.1f, bw * 0.1f, p);
        // cabina
        p.setColor(0xFFD3D9E2);
        c.drawRoundRect(new RectF(cx - bw * 0.34f, top, cx + bw * 0.34f, top + bh * 0.45f), bw * 0.08f, bw * 0.08f, p);
        // parabrisas
        p.setColor(0xFF2A3547);
        c.drawRoundRect(new RectF(cx - bw * 0.28f, top + bh * 0.06f, cx + bw * 0.28f, top + bh * 0.4f), bw * 0.05f, bw * 0.05f, p);
        // parrilla
        c.drawRoundRect(new RectF(cx - bw * 0.16f, top + bh * 0.64f, cx + bw * 0.16f, top + bh * 0.82f), bw * 0.03f, bw * 0.03f, p);
        // faros
        p.setColor(on ? 0xFFFFE066 : 0xFF8C96A5);
        c.drawRoundRect(new RectF(cx - bw * 0.44f, top + bh * 0.5f, cx - bw * 0.22f, top + bh * 0.64f), bw * 0.03f, bw * 0.03f, p);
        c.drawRoundRect(new RectF(cx + bw * 0.22f, top + bh * 0.5f, cx + bw * 0.44f, top + bh * 0.64f), bw * 0.03f, bw * 0.03f, p);
        // llantas
        p.setColor(0xFF1A2230);
        c.drawRoundRect(new RectF(cx - bw * 0.42f, top + bh * 0.86f, cx - bw * 0.24f, top + bh * 1.0f), bw * 0.02f, bw * 0.02f, p);
        c.drawRoundRect(new RectF(cx + bw * 0.24f, top + bh * 0.86f, cx + bw * 0.42f, top + bh * 1.0f), bw * 0.02f, bw * 0.02f, p);
    }
}
