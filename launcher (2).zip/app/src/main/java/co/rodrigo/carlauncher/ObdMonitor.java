package co.rodrigo.carlauncher;

import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothSocket;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.UUID;

/** Lee el adaptador OBD2 (ELM327 Bluetooth) en un hilo propio. */
public class ObdMonitor {
    private static ObdMonitor inst;

    public static synchronized ObdMonitor get() {
        if (inst == null) inst = new ObdMonitor();
        return inst;
    }

    public static final int YELLOW = 100; // °C: aviso amarillo
    public static final int RED = 108;    // °C: alerta roja
    private static final UUID SPP = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    public volatile boolean connected = false;
    public volatile String status = "Sin conexión";
    public volatile int rpm = -1, speed = -1, load = -1;
    public volatile int temp = -999;
    public volatile double volts = -1;
    public volatile double maf = -1;
    public volatile boolean mafOk = true;
    public volatile int tempLevel = 0;
    public volatile boolean mil = false;
    public volatile String dtcText = "";
    public volatile double tripKm = 0, fuelL = 0, oilKm = 0;
    public volatile long tripStartMs = 0, lastData = 0;

    private volatile boolean running = false;
    private Context app;
    private SharedPreferences sp;
    private BluetoothSocket sock;
    private InputStream in;
    private OutputStream out;
    private final ArrayList<Integer> tempHist = new ArrayList<>();
    private final ArrayList<Double> voltHist = new ArrayList<>();
    private int hiRed = 0, hiYel = 0;

    public synchronized void start(Context c) {
        if (running) return;
        app = c.getApplicationContext();
        sp = app.getSharedPreferences("launcher", Context.MODE_PRIVATE);
        oilKm = sp.getFloat("oilKm", 0f);
        running = true;
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                loop();
            }
        }, "obd");
        t.setDaemon(true);
        t.start();
    }

    public void resetOil() {
        oilKm = 0;
        if (sp != null) sp.edit().putFloat("oilKm", 0f).apply();
    }

    private void pause(long ms) {
        try {
            Thread.sleep(ms);
        } catch (InterruptedException ignored) {
        }
    }

    private void loop() {
        while (running) {
            try {
                session();
            } catch (Exception e) {
                status = "Reconectando…";
            }
            connected = false;
            closeQuiet();
            pause(5000);
        }
    }

    private void closeQuiet() {
        try {
            if (sock != null) sock.close();
        } catch (Exception ignored) {
        }
        sock = null;
    }

    private void session() throws Exception {
        BluetoothManager bm = (BluetoothManager) app.getSystemService(Context.BLUETOOTH_SERVICE);
        BluetoothAdapter ad = bm == null ? null : bm.getAdapter();
        if (ad == null || !ad.isEnabled()) {
            status = "Bluetooth apagado";
            return;
        }
        if (Build.VERSION.SDK_INT >= 31 && app.checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)
                != PackageManager.PERMISSION_GRANTED) {
            status = "Falta permiso de Bluetooth";
            return;
        }
        BluetoothDevice dev = null;
        for (BluetoothDevice d : ad.getBondedDevices()) {
            String n = d.getName();
            if (n == null) continue;
            String u = n.toUpperCase();
            if (u.contains("OBD") || u.contains("ELM") || u.contains("V-LINK")) {
                dev = d;
                break;
            }
        }
        if (dev == null) {
            status = "Empareja el adaptador OBDII";
            return;
        }
        status = "Conectando…";
        ad.cancelDiscovery();
        try {
            sock = dev.createRfcommSocketToServiceRecord(SPP);
            sock.connect();
        } catch (IOException e) {
            closeQuiet();
            try {
                sock = (BluetoothSocket) dev.getClass().getMethod("createRfcommSocket", int.class).invoke(dev, 1);
                sock.connect();
            } catch (Exception e2) {
                status = "No pude conectar";
                throw new IOException("connect");
            }
        }
        in = sock.getInputStream();
        out = sock.getOutputStream();
        status = "Iniciando…";
        send("ATZ", 3000);
        send("ATE0", 1500);
        send("ATL0", 1500);
        send("ATS0", 1500);
        send("ATH0", 1500);
        send("ATSP0", 1500);
        send("0100", 12000);

        long now = System.currentTimeMillis();
        if (tripStartMs == 0 || now - lastData > 600000) {
            tripKm = 0;
            fuelL = 0;
            tripStartMs = now;
        }
        lastData = now;
        connected = true;
        status = "Conectado";

        int cycle = 0, fails = 0, mafFail = 0;
        long lastT = System.currentTimeMillis(), lastSave = lastT, lastDtc = 0;
        while (running) {
            boolean got = false;
            int[] x = q("0C", 2);
            if (x != null) {
                rpm = (x[0] * 256 + x[1]) / 4;
                got = true;
            }
            x = q("05", 1);
            if (x != null) {
                updateTemp(x[0] - 40);
                got = true;
            }
            x = q("0D", 1);
            if (x != null) {
                speed = x[0];
                got = true;
            }
            x = q("42", 2);
            if (x != null) updateVolts((x[0] * 256 + x[1]) / 1000.0);
            if (cycle % 3 == 0) {
                x = q("04", 1);
                if (x != null) load = x[0] * 100 / 255;
                if (mafOk) {
                    x = q("10", 2);
                    if (x != null) {
                        maf = (x[0] * 256 + x[1]) / 100.0;
                        mafFail = 0;
                    } else if (++mafFail > 5) {
                        mafOk = false;
                        maf = -1;
                    }
                }
            }
            long t = System.currentTimeMillis();
            long dt = t - lastT;
            lastT = t;
            if (got) {
                fails = 0;
                lastData = t;
                if (speed >= 0) {
                    double km = speed * dt / 3600000.0;
                    tripKm += km;
                    oilKm += km;
                }
                if (maf >= 0) {
                    double lph = maf * 3600.0 / (14.7 * 740.0);
                    fuelL += lph * dt / 3600000.0;
                }
            } else if (++fails > 8) {
                throw new IOException("sin datos");
            }
            if (t - lastSave > 20000) {
                lastSave = t;
                sp.edit().putFloat("oilKm", (float) oilKm).apply();
            }
            if (t - lastDtc > 30000) {
                lastDtc = t;
                readDtc();
            }
            cycle++;
            pause(100);
        }
    }

    private void readDtc() {
        try {
            int[] x = q("01", 4);
            if (x == null) return;
            mil = (x[0] & 0x80) != 0;
            int count = x[0] & 0x7F;
            if (count > 0) {
                dtcText = decodeDtc(send("03", 4000));
            } else {
                dtcText = "";
            }
        } catch (Exception ignored) {
        }
    }

    private String decodeDtc(String resp) {
        try {
            String s = clean(resp);
            int i = s.indexOf("43");
            if (i < 0) return "Falla registrada";
            i += 4; // salta "43" y el contador (CAN)
            StringBuilder sb = new StringBuilder();
            int found = 0;
            while (i + 4 <= s.length() && found < 4) {
                int b1 = Integer.parseInt(s.substring(i, i + 2), 16);
                int b2 = Integer.parseInt(s.substring(i + 2, i + 4), 16);
                i += 4;
                if (b1 == 0 && b2 == 0) break;
                char l = "PCBU".charAt((b1 >> 6) & 3);
                String code = "" + l + ((b1 >> 4) & 3) + Integer.toHexString(b1 & 0xF).toUpperCase()
                        + (b2 < 16 ? "0" : "") + Integer.toHexString(b2).toUpperCase();
                if (sb.length() > 0) sb.append(" ");
                sb.append(code);
                found++;
            }
            return sb.length() > 0 ? sb.toString() : "Falla registrada";
        } catch (Exception e) {
            return "Falla registrada";
        }
    }

    private void updateTemp(int t) {
        tempHist.add(t);
        if (tempHist.size() > 3) tempHist.remove(0);
        Integer[] a = tempHist.toArray(new Integer[0]);
        Arrays.sort(a);
        int med = a[a.length / 2];
        temp = med;
        hiRed = med >= RED ? hiRed + 1 : 0;
        hiYel = med >= YELLOW ? hiYel + 1 : 0;
        if (hiRed >= 4) tempLevel = 2;
        else if (hiYel >= 4 && tempLevel < 2) tempLevel = 1;
        if (tempLevel == 2 && med < RED - 3) tempLevel = med >= YELLOW ? 1 : 0;
        if (tempLevel == 1 && med < YELLOW - 3) tempLevel = 0;
    }

    private void updateVolts(double v) {
        voltHist.add(v);
        if (voltHist.size() > 5) voltHist.remove(0);
        Double[] a = voltHist.toArray(new Double[0]);
        Arrays.sort(a);
        volts = a[a.length / 2];
    }

    private String clean(String s) {
        return s.replace(" ", "").replace("\r", "").replace("\n", "").toUpperCase();
    }

    private int[] q(String pid, int n) throws IOException {
        String s = clean(send("01" + pid, 3000));
        String key = "41" + pid;
        int i = s.indexOf(key);
        if (i < 0) return null;
        i += key.length();
        if (s.length() < i + 2 * n) return null;
        int[] r = new int[n];
        try {
            for (int k = 0; k < n; k++) r[k] = Integer.parseInt(s.substring(i + 2 * k, i + 2 * k + 2), 16);
        } catch (NumberFormatException e) {
            return null;
        }
        return r;
    }

    private String send(String cmd, int timeoutMs) throws IOException {
        while (in.available() > 0) in.read();
        out.write((cmd + "\r").getBytes());
        out.flush();
        StringBuilder sb = new StringBuilder();
        long end = System.currentTimeMillis() + timeoutMs;
        while (System.currentTimeMillis() < end) {
            if (in.available() > 0) {
                int b = in.read();
                if (b < 0) throw new IOException("eof");
                if (b == '>') break;
                sb.append((char) b);
            } else {
                pause(15);
            }
        }
        return sb.toString();
    }
}
