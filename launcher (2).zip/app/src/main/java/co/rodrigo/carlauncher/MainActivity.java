package co.rodrigo.carlauncher;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.database.ContentObserver;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.SpannableString;
import android.text.style.ForegroundColorSpan;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextClock;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    static final int BLUE = 0xFF4DA3FF, VIOLET = 0xFFB58CFF, BG = 0xFF0B0F17, CARD = 0xFF141B27,
            TXT = 0xFFEAF0FA, MUTED = 0xFF9FB0C8, GREEN = 0xFF3DDC97, AMBER = 0xFFFFC93C,
            RED = 0xFFFF4D4D, WHITE = 0xFFF5F8FF;
    static final double OIL_INTERVAL = 5000; // km entre cambios de aceite
    static final Locale CO = new Locale("es", "CO");

    float S;
    SharedPreferences sp;
    final Handler h = new Handler(Looper.getMainLooper());
    FrameLayout root;
    View selectV, homeV, vehV, alertV;
    String profile = null;
    int accent = BLUE;
    boolean lightsOn = false, alertDismissed = false, resumed = false;
    int lastLevel = 0, lastBr = -1;
    long lastBeep = 0;
    String weatherTxt = "Cali", rainTxt = "";
    ToneGenerator tone;
    ContentObserver brObs;
    NumberFormat nf0, nf1;
    SimpleDateFormat dateFmt = new SimpleDateFormat("d MMM yyyy", CO);

    // inicio
    TextView hGreet, hName, hWeather, chipTemp, chipBat, chipDtc, chipRain, chipPyp;
    Card cRadio, cOil, cSpeed;
    View btnVeh;
    // vehículo
    TextView vWho, lightsBtn;
    Card vTemp, vBat, vDtc, vRpm, vFuel, vTrip, vSoat, vTecno;
    CarView carView;
    // alerta
    TextView aTemp;

    // ---------- utilidades de interfaz ----------
    int dp(float v) {
        return Math.round(v * S);
    }

    LinearLayout vbox() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    LinearLayout hbox() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        return l;
    }

    LinearLayout.LayoutParams lp(int w, int hh, float wt) {
        return new LinearLayout.LayoutParams(w, hh, wt);
    }

    TextView tv(String s, float size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextColor(color);
        t.setTextSize(TypedValue.COMPLEX_UNIT_PX, size * S);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    GradientDrawable round(int color, float radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        return g;
    }

    void setChip(TextView t, String text, int dot) {
        SpannableString s = new SpannableString("● " + text);
        s.setSpan(new ForegroundColorSpan(dot), 0, 1, 0);
        t.setText(s);
    }

    TextView chip() {
        TextView t = tv("", 16, TXT, false);
        t.setBackground(round(CARD, 18));
        t.setPadding(dp(14), dp(7), dp(14), dp(7));
        return t;
    }

    class Bar extends LinearLayout {
        View on, off;

        Bar() {
            super(MainActivity.this);
            setOrientation(HORIZONTAL);
            setBackground(round(0xFF222C3C, 5));
            on = new View(MainActivity.this);
            off = new View(MainActivity.this);
            addView(on, new LayoutParams(0, LayoutParams.MATCH_PARENT, 0));
            addView(off, new LayoutParams(0, LayoutParams.MATCH_PARENT, 100));
        }

        void set(int pct, int color) {
            pct = Math.max(0, Math.min(100, pct));
            on.setBackground(round(color, 5));
            ((LayoutParams) on.getLayoutParams()).weight = pct;
            ((LayoutParams) off.getLayoutParams()).weight = 100 - pct;
            requestLayout();
        }
    }

    class Card {
        LinearLayout box;
        TextView lab, big, sub;
        Bar bar;

        Card(String label, boolean withBar) {
            box = vbox();
            box.setBackground(round(CARD, 24));
            box.setPadding(dp(20), dp(12), dp(20), dp(12));
            box.setGravity(Gravity.CENTER_VERTICAL);
            lab = tv(label, 14, MUTED, false);
            big = tv("--", 36, TXT, true);
            sub = tv(" ", 15, MUTED, false);
            box.addView(lab);
            box.addView(big);
            if (withBar) {
                bar = new Bar();
                LinearLayout.LayoutParams p = lp(-1, dp(9), 0);
                p.topMargin = dp(4);
                p.bottomMargin = dp(2);
                box.addView(bar, p);
            }
            box.addView(sub);
        }
    }

    LinearLayout row(float weight, Object... items) {
        LinearLayout r = hbox();
        for (Object o : items) {
            View v;
            float w = 1f;
            if (o instanceof Card) {
                v = ((Card) o).box;
            } else {
                v = (View) o;
            }
            LinearLayout.LayoutParams p = lp(0, -1, w);
            p.leftMargin = dp(6);
            p.rightMargin = dp(6);
            r.addView(v, p);
        }
        r.setLayoutParams(lp(-1, 0, weight));
        return r;
    }

    // ---------- ciclo de vida ----------
    @Override
    protected void onCreate(android.os.Bundle b) {
        super.onCreate(b);
        DisplayMetrics dm = getResources().getDisplayMetrics();
        S = Math.min(dm.widthPixels / 1000f, dm.heightPixels / 620f);
        sp = getSharedPreferences("launcher", MODE_PRIVATE);
        nf0 = NumberFormat.getIntegerInstance(CO);
        nf1 = NumberFormat.getNumberInstance(CO);
        nf1.setMaximumFractionDigits(1);
        nf1.setMinimumFractionDigits(1);

        root = new FrameLayout(this);
        root.setBackgroundColor(BG);
        selectV = buildSelect();
        homeV = buildHome();
        vehV = buildVehicle();
        alertV = buildAlert();
        root.addView(selectV);
        root.addView(homeV);
        root.addView(vehV);
        root.addView(alertV);
        setContentView(root);
        showOnly(selectV);
        alertV.setVisibility(View.GONE);

        if (Build.VERSION.SDK_INT >= 31
                && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT}, 1);
        } else {
            ObdMonitor.get().start(this);
        }

        brObs = new ContentObserver(h) {
            @Override
            public void onChange(boolean selfChange) {
                onBrightness();
            }
        };
        try {
            getContentResolver().registerContentObserver(
                    Settings.System.getUriFor(Settings.System.SCREEN_BRIGHTNESS), false, brObs);
            lastBr = Settings.System.getInt(getContentResolver(), Settings.System.SCREEN_BRIGHTNESS, -1);
        } catch (Exception ignored) {
        }

        fetchWeather();
        tick();
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        ObdMonitor.get().start(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        resumed = true;
    }

    @Override
    protected void onPause() {
        super.onPause();
        resumed = false;
    }

    @Override
    protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        if (profile != null) showOnly(homeV);
    }

    @Override
    public void onBackPressed() {
        if (vehV.getVisibility() == View.VISIBLE) showOnly(homeV);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        h.removeCallbacksAndMessages(null);
        try {
            getContentResolver().unregisterContentObserver(brObs);
        } catch (Exception ignored) {
        }
    }

    void showOnly(View v) {
        selectV.setVisibility(v == selectV ? View.VISIBLE : View.GONE);
        homeV.setVisibility(v == homeV ? View.VISIBLE : View.GONE);
        vehV.setVisibility(v == vehV ? View.VISIBLE : View.GONE);
    }

    // ---------- pantallas ----------
    View buildSelect() {
        LinearLayout v = vbox();
        v.setBackgroundColor(BG);
        v.setGravity(Gravity.CENTER);
        TextView t = tv("¿Quién maneja hoy?", 54, WHITE, true);
        t.setGravity(Gravity.CENTER);
        v.addView(t, lp(-2, -2, 0));
        LinearLayout r = hbox();
        r.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams p = lp(dp(380), dp(230), 0);
        p.setMargins(dp(20), dp(40), dp(20), 0);
        r.addView(profileBtn("Rodrigo", BLUE), p);
        r.addView(profileBtn("Alejandra", VIOLET), p);
        v.addView(r, lp(-2, -2, 0));
        return v;
    }

    View profileBtn(final String name, final int color) {
        LinearLayout b = vbox();
        b.setGravity(Gravity.CENTER);
        GradientDrawable g = round(CARD, 36);
        g.setStroke(dp(3), color);
        b.setBackground(g);
        View dot = new View(this);
        dot.setBackground(round(color, 42));
        b.addView(dot, lp(dp(84), dp(84), 0));
        TextView t = tv(name, 42, WHITE, true);
        t.setPadding(0, dp(12), 0, 0);
        b.addView(t);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setProfile(name);
            }
        });
        return b;
    }

    void setProfile(String name) {
        profile = name;
        accent = name.equals("Rodrigo") ? BLUE : VIOLET;
        hName.setText(name);
        vWho.setText(name);
        hGreet.setTextColor(accent);
        vWho.setTextColor(accent);
        btnVeh.setBackground(round(accent, 22));
        showOnly(homeV);
    }

    View appBtn(String label, int iconColor, boolean filled, View.OnClickListener l) {
        LinearLayout b = vbox();
        b.setGravity(Gravity.CENTER);
        b.setBackground(round(filled ? accent : 0xFF1A2230, 22));
        View ic = new View(this);
        ic.setBackground(round(filled ? 0xFF0B0F17 : iconColor, 12));
        b.addView(ic, lp(dp(34), dp(34), 0));
        TextView t = tv(label, 15, filled ? 0xFF0B0F17 : TXT, true);
        t.setPadding(0, dp(6), 0, 0);
        t.setGravity(Gravity.CENTER);
        b.addView(t);
        b.setOnClickListener(l);
        return b;
    }

    View buildHome() {
        LinearLayout v = vbox();
        v.setBackgroundColor(BG);
        v.setPadding(dp(30), dp(20), dp(30), dp(20));

        LinearLayout head = hbox();
        LinearLayout left = vbox();
        hGreet = tv("BUENAS TARDES", 18, accent, true);
        hName = tv("", 44, WHITE, true);
        left.addView(hGreet);
        left.addView(hName);
        left.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View x) {
                showOnly(selectV);
            }
        });
        LinearLayout right = vbox();
        right.setGravity(Gravity.END);
        TextClock clock = new TextClock(this);
        clock.setFormat12Hour("h:mm a");
        clock.setFormat24Hour("h:mm a");
        clock.setTextColor(WHITE);
        clock.setTextSize(TypedValue.COMPLEX_UNIT_PX, 44 * S);
        clock.setTypeface(Typeface.DEFAULT_BOLD);
        hWeather = tv("Cali", 18, MUTED, false);
        hWeather.setGravity(Gravity.END);
        right.addView(clock);
        right.addView(hWeather);
        head.addView(left, lp(0, -2, 1));
        head.addView(right, lp(-2, -2, 0));
        v.addView(head, lp(-1, -2, 0));

        LinearLayout chips = hbox();
        chipTemp = chip();
        chipBat = chip();
        chipDtc = chip();
        chipRain = chip();
        chipPyp = chip();
        View[] cs = {chipTemp, chipBat, chipDtc, chipRain, chipPyp};
        for (View c : cs) {
            LinearLayout.LayoutParams p = lp(-2, -2, 0);
            p.rightMargin = dp(10);
            chips.addView(c, p);
        }
        LinearLayout.LayoutParams cp = lp(-1, -2, 0);
        cp.topMargin = dp(10);
        cp.bottomMargin = dp(12);
        v.addView(chips, cp);

        cRadio = new Card("RADIO FM", false);
        cRadio.big.setText("FM");
        cRadio.sub.setText("Toca para abrir la radio");
        cRadio.box.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View x) {
                launch(null, "radio", "fm");
            }
        });
        cOil = new Card("CAMBIO DE ACEITE", true);
        cOil.box.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View x) {
                confirmOilReset();
                return true;
            }
        });
        cSpeed = new Card("VELOCIDAD", false);
        v.addView(row(1, cRadio, cOil, cSpeed));

        LinearLayout apps = hbox();
        View[] ab = {
                appBtn("Waze", 0xFF33CCFF, false, launchL("com.waze", "waze")),
                appBtn("Spotify", 0xFF1ED760, false, launchL("com.spotify.music", "spotify")),
                appBtn("YT Music", 0xFFFF4E45, false, launchL("com.google.android.apps.youtube.music", "youtube music", "yt music")),
                appBtn("ZLINK5", 0xFF2F7DFF, false, launchL(null, "zlink")),
                appBtn("360", 0xFFF2B84B, false, launchL(null, "360")),
                appBtn("Apps", 0xFF9FB0C8, false, new View.OnClickListener() {
                    @Override
                    public void onClick(View x) {
                        showAllApps();
                    }
                }),
        };
        btnVeh = appBtn("Vehículo", 0xFF0B0F17, true, new View.OnClickListener() {
            @Override
            public void onClick(View x) {
                showOnly(vehV);
            }
        });
        for (View b : ab) {
            LinearLayout.LayoutParams p = lp(0, dp(88), 1);
            p.leftMargin = dp(6);
            p.rightMargin = dp(6);
            apps.addView(b, p);
        }
        LinearLayout.LayoutParams p2 = lp(0, dp(88), 1);
        p2.leftMargin = dp(6);
        p2.rightMargin = dp(6);
        apps.addView(btnVeh, p2);
        LinearLayout.LayoutParams ap = lp(-1, -2, 0);
        ap.topMargin = dp(12);
        v.addView(apps, ap);
        return v;
    }

    View buildVehicle() {
        LinearLayout v = vbox();
        v.setBackgroundColor(BG);
        v.setPadding(dp(30), dp(16), dp(30), dp(16));

        LinearLayout top = hbox();
        top.setGravity(Gravity.CENTER_VERTICAL);
        TextView back = tv("◀ Inicio", 17, TXT, true);
        back.setBackground(round(0xFF1A2230, 22));
        back.setPadding(dp(20), dp(10), dp(20), dp(10));
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View x) {
                showOnly(homeV);
            }
        });
        TextView title = tv("Vehículo", 32, WHITE, true);
        title.setPadding(dp(16), 0, 0, 0);
        vWho = tv("", 18, accent, true);
        TextView cfg = tv("Ajustes", 17, TXT, true);
        cfg.setBackground(round(0xFF1A2230, 22));
        cfg.setPadding(dp(20), dp(10), dp(20), dp(10));
        cfg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View x) {
                showSettings();
            }
        });
        top.addView(back);
        top.addView(title, lp(0, -2, 1));
        vWho.setPadding(0, 0, dp(16), 0);
        top.addView(vWho);
        top.addView(cfg);
        LinearLayout.LayoutParams tp = lp(-1, -2, 0);
        tp.bottomMargin = dp(10);
        v.addView(top, tp);

        // tarjeta del carro
        LinearLayout carBox = vbox();
        carBox.setBackground(round(CARD, 24));
        carBox.setPadding(dp(12), dp(10), dp(12), dp(10));
        carView = new CarView(this);
        carBox.addView(carView, lp(-1, 0, 1));
        lightsBtn = tv("Luces: apagadas", 16, TXT, true);
        lightsBtn.setGravity(Gravity.CENTER);
        lightsBtn.setBackground(round(0xFF222C3C, 18));
        lightsBtn.setPadding(dp(10), dp(8), dp(10), dp(8));
        lightsBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View x) {
                setLights(!lightsOn);
            }
        });
        carBox.addView(lightsBtn, lp(-1, -2, 0));

        vTemp = new Card("TEMPERATURA DEL MOTOR", true);
        vBat = new Card("BATERÍA", true);
        vDtc = new Card("LUZ CHECK ENGINE", false);
        vRpm = new Card("RPM Y CARGA", true);
        vFuel = new Card("CONSUMO ESTIMADO", false);
        vTrip = new Card("VIAJE", false);
        vSoat = new Card("SOAT", true);
        vTecno = new Card("REVISIÓN TÉCNICO-MECÁNICA", true);
        vSoat.box.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View x) {
                pickDate("soat");
            }
        });
        vTecno.box.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View x) {
                pickDate("tecno");
            }
        });

        LinearLayout r1 = row(1, carBox, vTemp, vBat);
        v.addView(r1);
        v.addView(row(1, vDtc, vRpm, vFuel));
        v.addView(row(1, vTrip, vSoat, vTecno));
        for (int i = 1; i < v.getChildCount(); i++) {
            ((LinearLayout.LayoutParams) v.getChildAt(i).getLayoutParams()).topMargin = dp(6);
        }
        return v;
    }

    View buildAlert() {
        LinearLayout v = vbox();
        v.setBackgroundColor(0xFFB3161B);
        v.setGravity(Gravity.CENTER);
        TextView a = tv("ALERTA DE MOTOR", 26, 0xFFFFFFFF, true);
        TextView b = tv("MOTOR CALIENTE", 90, 0xFFFFFFFF, true);
        aTemp = tv("-- °C", 64, 0xFFFFFFFF, true);
        TextView c = tv("Detén el carro en un lugar seguro y apaga el motor.", 28, 0xFFFFFFFF, false);
        c.setGravity(Gravity.CENTER);
        TextView ok = tv("Entendido", 26, 0xFF8E0F13, true);
        ok.setBackground(round(0xFFFFFFFF, 32));
        ok.setPadding(dp(48), dp(16), dp(48), dp(16));
        ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View x) {
                alertDismissed = true;
                alertV.setVisibility(View.GONE);
            }
        });
        LinearLayout.LayoutParams p = lp(-2, -2, 0);
        p.topMargin = dp(16);
        v.addView(a);
        v.addView(b);
        v.addView(aTemp);
        v.addView(c, p);
        v.addView(ok, p);
        v.setClickable(true);
        return v;
    }

    // ---------- acciones ----------
    View.OnClickListener launchL(final String pkg, final String... needles) {
        return new View.OnClickListener() {
            @Override
            public void onClick(View x) {
                launch(pkg, needles);
            }
        };
    }

    void launch(String pkg, String... needles) {
        PackageManager pm = getPackageManager();
        try {
            if (pkg != null) {
                Intent i = pm.getLaunchIntentForPackage(pkg);
                if (i != null) {
                    startActivity(i);
                    return;
                }
            }
            Intent main = new Intent(Intent.ACTION_MAIN);
            main.addCategory(Intent.CATEGORY_LAUNCHER);
            for (ResolveInfo ri : pm.queryIntentActivities(main, 0)) {
                if (ri.activityInfo.packageName.equals(getPackageName())) continue;
                String l = ri.loadLabel(pm).toString().toLowerCase();
                for (String n : needles) {
                    if (l.contains(n)) {
                        Intent i = pm.getLaunchIntentForPackage(ri.activityInfo.packageName);
                        if (i != null) {
                            startActivity(i);
                            return;
                        }
                    }
                }
            }
        } catch (Exception ignored) {
        }
        Toast.makeText(this, "No encontré esa app", Toast.LENGTH_SHORT).show();
    }

    void showAllApps() {
        final PackageManager pm = getPackageManager();
        Intent main = new Intent(Intent.ACTION_MAIN);
        main.addCategory(Intent.CATEGORY_LAUNCHER);
        final List<String> labels = new ArrayList<>();
        final List<String> pkgs = new ArrayList<>();
        List<ResolveInfo> all = pm.queryIntentActivities(main, 0);
        Collections.sort(all, new ResolveInfo.DisplayNameComparator(pm));
        for (ResolveInfo ri : all) {
            if (ri.activityInfo.packageName.equals(getPackageName())) continue;
            labels.add(ri.loadLabel(pm).toString());
            pkgs.add(ri.activityInfo.packageName);
        }
        new AlertDialog.Builder(this).setTitle("Todas las apps")
                .setItems(labels.toArray(new String[0]), new android.content.DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(android.content.DialogInterface d, int which) {
                        Intent i = pm.getLaunchIntentForPackage(pkgs.get(which));
                        if (i != null) startActivity(i);
                    }
                }).show();
    }

    void showSettings() {
        String[] items = {"Día de pico y placa", "Reiniciar contador de aceite", "Cambiar de perfil"};
        new AlertDialog.Builder(this).setTitle("Ajustes")
                .setItems(items, new android.content.DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(android.content.DialogInterface d, int which) {
                        if (which == 0) pickPyp();
                        else if (which == 1) confirmOilReset();
                        else showOnly(selectV);
                    }
                }).show();
    }

    void pickPyp() {
        String[] days = {"Ninguno", "Lunes", "Martes", "Miércoles", "Jueves", "Viernes"};
        new AlertDialog.Builder(this).setTitle("Día de pico y placa")
                .setItems(days, new android.content.DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(android.content.DialogInterface d, int which) {
                        sp.edit().putInt("pyp", which).apply();
                    }
                }).show();
    }

    void confirmOilReset() {
        new AlertDialog.Builder(this).setTitle("¿Ya cambiaste el aceite?")
                .setMessage("El contador volverá a " + nf0.format(OIL_INTERVAL) + " km.")
                .setPositiveButton("Sí, reiniciar", new android.content.DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(android.content.DialogInterface d, int w) {
                        ObdMonitor.get().resetOil();
                    }
                }).setNegativeButton("Cancelar", null).show();
    }

    void pickDate(final String key) {
        Calendar c = Calendar.getInstance();
        long cur = sp.getLong(key, 0);
        if (cur > 0) c.setTimeInMillis(cur);
        new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(android.widget.DatePicker view, int y, int m, int d) {
                Calendar x = Calendar.getInstance();
                x.set(y, m, d, 12, 0, 0);
                sp.edit().putLong(key, x.getTimeInMillis()).apply();
            }
        }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show();
    }

    void setLights(boolean on) {
        lightsOn = on;
        carView.setLights(on);
        lightsBtn.setText(on ? "Luces: encendidas" : "Luces: apagadas");
        lightsBtn.setBackground(round(on ? 0xFF7A6A1E : 0xFF222C3C, 18));
    }

    void onBrightness() {
        try {
            int v = Settings.System.getInt(getContentResolver(), Settings.System.SCREEN_BRIGHTNESS, -1);
            if (v >= 0 && lastBr > 0) {
                if (v < lastBr * 0.7) setLights(true);
                else if (v > lastBr * 1.3) setLights(false);
            }
            if (v >= 0) lastBr = v;
        } catch (Exception ignored) {
        }
    }

    // ---------- clima ----------
    String weatherText(int c) {
        if (c == 0) return "Despejado";
        if (c <= 2) return "Parcialmente nublado";
        if (c == 3) return "Nublado";
        if (c == 45 || c == 48) return "Niebla";
        if (c >= 51 && c <= 57) return "Llovizna";
        if (c >= 61 && c <= 67) return "Lluvia";
        if (c >= 80 && c <= 82) return "Chubascos";
        if (c >= 95) return "Tormenta";
        return "Variable";
    }

    void fetchWeather() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    URL u = new URL("https://api.open-meteo.com/v1/forecast?latitude=3.4516&longitude=-76.532"
                            + "&current=temperature_2m,weather_code&minutely_15=precipitation"
                            + "&forecast_minutely_15=96&timezone=auto");
                    HttpURLConnection c = (HttpURLConnection) u.openConnection();
                    c.setConnectTimeout(8000);
                    c.setReadTimeout(8000);
                    BufferedReader rd = new BufferedReader(new InputStreamReader(c.getInputStream()));
                    StringBuilder sb = new StringBuilder();
                    String line;
                    while ((line = rd.readLine()) != null) sb.append(line);
                    rd.close();
                    JSONObject j = new JSONObject(sb.toString());
                    JSONObject cur = j.getJSONObject("current");
                    long tmp = Math.round(cur.getDouble("temperature_2m"));
                    int code = cur.getInt("weather_code");
                    String now = cur.getString("time");
                    JSONObject mm = j.getJSONObject("minutely_15");
                    JSONArray tt = mm.getJSONArray("time");
                    JSONArray pp = mm.getJSONArray("precipitation");
                    int start = -1;
                    for (int i = 0; i < tt.length(); i++) {
                        if (tt.getString(i).compareTo(now) >= 0) {
                            start = i;
                            break;
                        }
                    }
                    String rain = "";
                    if (start >= 0) {
                        for (int k = start; k < Math.min(start + 4, tt.length()); k++) {
                            if (pp.optDouble(k, 0) >= 0.2) {
                                int mins = (k - start) * 15;
                                rain = mins == 0 ? "Lluvia ahora" : "Lluvia en " + mins + " min";
                                break;
                            }
                        }
                    }
                    final String w = "Cali · " + tmp + "° · " + weatherText(code);
                    final String rn = rain;
                    h.post(new Runnable() {
                        @Override
                        public void run() {
                            weatherTxt = w;
                            rainTxt = rn;
                        }
                    });
                } catch (Exception ignored) {
                }
            }
        }).start();
        h.postDelayed(new Runnable() {
            @Override
            public void run() {
                fetchWeather();
            }
        }, 15 * 60 * 1000);
    }

    // ---------- actualización cada segundo ----------
    void tick() {
        try {
            update();
        } catch (Exception ignored) {
        }
        h.postDelayed(new Runnable() {
            @Override
            public void run() {
                tick();
            }
        }, 1000);
    }

    void dateCard(Card c, String key) {
        long t = sp.getLong(key, 0);
        if (t == 0) {
            c.big.setText("--");
            c.sub.setText("Toca para poner la fecha de vencimiento");
            c.bar.set(0, MUTED);
            return;
        }
        long days = Math.round((t - System.currentTimeMillis()) / 86400000.0);
        c.big.setText(days >= 0 ? days + " días" : "Vencido");
        int col = days >= 60 ? GREEN : (days >= 30 ? AMBER : RED);
        c.bar.set((int) (Math.max(0, Math.min(365, days)) * 100 / 365), col);
        c.sub.setText((days >= 0 ? "Vence " : "Venció ") + dateFmt.format(new Date(t)));
    }

    void update() {
        ObdMonitor m = ObdMonitor.get();
        boolean conn = m.connected;
        Calendar cal = Calendar.getInstance();
        int hr = cal.get(Calendar.HOUR_OF_DAY);
        hGreet.setText(hr < 12 ? "BUENOS DÍAS" : (hr < 19 ? "BUENAS TARDES" : "BUENAS NOCHES"));
        hWeather.setText(weatherTxt);

        // avisos
        if (!conn) {
            setChip(chipTemp, m.status, MUTED);
            setChip(chipBat, "Batería --", MUTED);
            setChip(chipDtc, "Fallas --", MUTED);
        } else {
            int lvl = m.tempLevel;
            setChip(chipTemp, "Motor " + m.temp + " °C", lvl == 2 ? RED : (lvl == 1 ? AMBER : GREEN));
            double vv = m.volts;
            int bc = vv < 11.8 ? RED : (vv < 12.2 ? AMBER : GREEN);
            setChip(chipBat, vv > 0 ? "Batería " + nf1.format(vv) + " V" : "Batería --", vv > 0 ? bc : MUTED);
            if (m.mil) setChip(chipDtc, "Check engine " + m.dtcText, AMBER);
            else setChip(chipDtc, "Sin fallas", GREEN);
        }
        chipRain.setVisibility(rainTxt.isEmpty() ? View.GONE : View.VISIBLE);
        setChip(chipRain, rainTxt, accent);
        int pyp = sp.getInt("pyp", 0);
        String pt = "";
        if (pyp > 0) {
            int dow = cal.get(Calendar.DAY_OF_WEEK); // domingo = 1
            int today = dow - 1;                       // lunes = 1 ... viernes = 5
            int tomorrow = today == 7 ? 1 : today + 1;
            if (today == pyp) pt = "Hoy: pico y placa";
            else if (tomorrow == pyp) pt = "Mañana: pico y placa";
        }
        chipPyp.setVisibility(pt.isEmpty() ? View.GONE : View.VISIBLE);
        setChip(chipPyp, pt, AMBER);

        // inicio: aceite y velocidad
        double rem = Math.max(0, OIL_INTERVAL - m.oilKm);
        cOil.big.setText(nf0.format(Math.round(rem)) + " km");
        cOil.bar.set((int) (rem * 100 / OIL_INTERVAL), rem < 500 ? RED : (rem < 1000 ? AMBER : accent));
        cOil.sub.setText("Mantén pulsado para reiniciar");
        cSpeed.big.setText(conn && m.speed >= 0 ? m.speed + " km/h" : "--");
        cSpeed.sub.setText(conn && m.rpm >= 0 ? nf0.format(m.rpm) + " rpm" : m.status);

        // vehículo
        if (conn && m.temp > -100) {
            vTemp.big.setText(m.temp + " °C");
            vTemp.bar.set((m.temp - 40) * 100 / 90, m.tempLevel == 2 ? RED : (m.tempLevel == 1 ? AMBER : GREEN));
            vTemp.sub.setText(m.tempLevel == 2 ? "¡Muy alta!" : (m.tempLevel == 1 ? "Alta, vigílala" : "Normal"));
        } else {
            vTemp.big.setText("--");
            vTemp.bar.set(0, MUTED);
            vTemp.sub.setText(m.status);
        }
        if (conn && m.volts > 0) {
            vBat.big.setText(nf1.format(m.volts) + " V");
            vBat.bar.set((int) ((m.volts - 10) * 100 / 5), m.volts < 11.8 ? RED : (m.volts < 12.2 ? AMBER : GREEN));
            String s = "En reposo";
            if (m.rpm > 500) s = m.volts >= 13.2 ? "Cargando bien" : "Carga baja";
            vBat.sub.setText(s);
        } else {
            vBat.big.setText("--");
            vBat.bar.set(0, MUTED);
            vBat.sub.setText(" ");
        }
        if (!conn) {
            vDtc.big.setText("--");
            vDtc.sub.setText(m.status);
        } else if (m.mil) {
            vDtc.big.setText(m.dtcText.isEmpty() ? "Activa" : m.dtcText);
            vDtc.big.setTextColor(AMBER);
            vDtc.sub.setText("Revisa el carro con un mecánico");
        } else {
            vDtc.big.setText("Sin códigos");
            vDtc.big.setTextColor(TXT);
            vDtc.sub.setText("Sin fallas registradas");
        }
        vRpm.big.setText(m.rpm >= 0 ? nf0.format(m.rpm) + " rpm" : "--");
        vRpm.bar.set(m.rpm >= 0 ? m.rpm * 100 / 7000 : 0, accent);
        vRpm.sub.setText(m.load >= 0 ? "Carga del motor " + m.load + " %" : " ");
        if (!m.mafOk) {
            vFuel.big.setText("No disponible");
            vFuel.sub.setText("El carro no entrega este dato");
        } else if (m.tripKm > 0.3 && m.fuelL > 0) {
            vFuel.big.setText(nf1.format(m.fuelL / m.tripKm * 100) + " L/100 km");
            vFuel.sub.setText("Promedio del viaje (estimado)");
        } else {
            vFuel.big.setText("--");
            vFuel.sub.setText("Se calcula al avanzar");
        }
        long mins = m.tripStartMs > 0 ? Math.max(0, (m.lastData - m.tripStartMs) / 60000) : 0;
        vTrip.big.setText(nf1.format(m.tripKm) + " km");
        double avg = mins > 0 ? m.tripKm / (mins / 60.0) : 0;
        vTrip.sub.setText(mins + " min · " + Math.round(avg) + " km/h promedio");
        dateCard(vSoat, "soat");
        dateCard(vTecno, "tecno");

        // alerta de motor caliente
        int level = m.tempLevel;
        long now = System.currentTimeMillis();
        if (level < 2) {
            alertDismissed = false;
            if (alertV.getVisibility() == View.VISIBLE) alertV.setVisibility(View.GONE);
        }
        if (level == 1 && lastLevel == 0) beep();
        if (level == 2 && !alertDismissed) {
            aTemp.setText(m.temp + " °C");
            if (alertV.getVisibility() != View.VISIBLE) {
                alertV.setVisibility(View.VISIBLE);
                if (!resumed) bringToFront();
            }
            if (now - lastBeep > 2000) {
                lastBeep = now;
                beep();
            }
        }
        lastLevel = level;
    }

    void beep() {
        try {
            if (tone == null) tone = new ToneGenerator(AudioManager.STREAM_ALARM, 100);
            tone.startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, 500);
        } catch (Exception ignored) {
        }
    }

    void bringToFront() {
        try {
            Intent i = new Intent(this, MainActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
            startActivity(i);
        } catch (Exception ignored) {
        }
    }
}
